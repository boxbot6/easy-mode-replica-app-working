package com.example.easymodereplica

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.drawable.Drawable
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.ImageView
import android.widget.TextView


class ApplicationAdapter(applicationContext: Context?, aToZNames: List<String>, aToZIcons: ArrayList<Drawable>) : BaseAdapter() {
    private var aToZNames: Array<String>
    private var aToZIcons: Array<Drawable>
    private var layoutInflater: LayoutInflater

    init {
        this.aToZNames = aToZNames.toTypedArray<String>()
        this.aToZIcons = aToZIcons.toTypedArray<Drawable>()
        layoutInflater = LayoutInflater.from(applicationContext)
    }

    override fun getCount(): Int {
        return aToZNames.size
    }

    override fun getItem(position: Int): Any? {
        return null
    }

    override fun getItemId(position: Int): Long {
        return 0
    }

    @SuppressLint("ViewHolder")
    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        val view: View = layoutInflater.inflate(R.layout.snippet_list_row, parent, false) // shadowed as var because val cannot be reassigned
        val appName = view.findViewById<TextView>(R.id.list_names)
        val appIcon = view.findViewById<ImageView>(R.id.list_icons)
        appName.text = aToZNames[position]
        appIcon.setImageDrawable(aToZIcons[position])
        return view
    }
}