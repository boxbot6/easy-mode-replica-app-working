package com.example.easymodereplica

import android.Manifest
import android.app.AlertDialog
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Bundle
import android.os.IBinder
import android.provider.Settings
import androidx.core.app.ActivityCompat


open class GPSTracker(private val mContext: Context) : Service(), LocationListener {
    private var isGPSEnabled = false
    private var isNetworkEnabled = false
    private var canGetLocation = false
    private lateinit var locationManager: LocationManager

    init {
        this.location
    }

    private val location: Location?
        get() {

            // The minimum distance to change for updates in meters
            val minDistanceChangeForUpdates: Long = 2 // 2 meters

            // The minimum time between updates in milliseconds
            val minTimeBetweenUpdates = (1000 * 60).toLong() // 1 minute (1000/sec)
            try {
                locationManager = mContext.getSystemService(LOCATION_SERVICE) as LocationManager

                // getting GPS status
                isGPSEnabled = locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)

                // getting network status
                isNetworkEnabled = locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER)
                if (!isGPSEnabled && !isNetworkEnabled) {
                    // no gps or network provider enabled
                } else {
                    canGetLocation = true

                    // first get location from network provider
                    if (isNetworkEnabled) {
                        if (ActivityCompat.checkSelfPermission(
                                this,
                                Manifest.permission.ACCESS_FINE_LOCATION
                            ) != PackageManager.PERMISSION_GRANTED &&
                            ActivityCompat.checkSelfPermission(
                                this,
                                Manifest.permission.ACCESS_COARSE_LOCATION
                            ) != PackageManager.PERMISSION_GRANTED
                        ) {
                            return null
                        }
                        locationManager.requestLocationUpdates(
                            LocationManager.NETWORK_PROVIDER,
                            minTimeBetweenUpdates,
                            minDistanceChangeForUpdates.toFloat(),
                            this
                        )
                        Companion.location = locationManager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER)
                        if (Companion.location != null) {
                            Companion.latitude = Companion.location!!.latitude
                            Companion.longitude = Companion.location!!.longitude
                        }
                    }

                    // if GPS enabled get lat/long using GPS provider
                    if (isGPSEnabled) {
                        if (Companion.location == null) {
                            Companion.location = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER)
                            locationManager.requestLocationUpdates(
                                LocationManager.GPS_PROVIDER,
                                minTimeBetweenUpdates,
                                minDistanceChangeForUpdates.toFloat(),
                                this
                            )
                            if (Companion.location != null) {
                                Companion.latitude = Companion.location!!.latitude
                                Companion.longitude = Companion.location!!.longitude
                            }
                        }
                    }
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
            return Companion.location
        }

    // Stop using GPS listener, calling this function will stop using GPS in your app
    fun stopUsingGPS() {
        if (ActivityCompat.checkSelfPermission(
                this,
                Manifest.permission.ACCESS_FINE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(
                this,
                Manifest.permission.ACCESS_COARSE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            return
        }
        locationManager.removeUpdates(this@GPSTracker)
    }

    val latitude: Double
        // functions to get latitude and longitude
        get() {
            if (Companion.location != null) {
                Companion.latitude = Companion.location!!.latitude
            }
            return Companion.latitude
        }
    val longitude: Double
        get() {
            if (Companion.location != null) {
                Companion.longitude = Companion.location!!.longitude
            }
            return Companion.longitude
        }

    // function to check whether GPS/WiFi is enabled
    fun canGetLocation(): Boolean {
        return canGetLocation
    }

    // function to show alert dialog, on pressing Settings button will launch settings options
    fun showSettingsDialog() {
        val alertDialog = AlertDialog.Builder(mContext)

        // Setting Dialog Title
        alertDialog.setTitle("GPS Settings")

        // Setting Dialog Message
        alertDialog.setMessage("GPS is not enabled. \nDo you want to go to settings menu?")

        // On pressing Settings button
        alertDialog.setPositiveButton("Settings") { _, _ -> // Implicit intent
            val intent = Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS)
            mContext.startActivity(intent)
        }

        // on pressing cancel button
        alertDialog.setNegativeButton("Cancel") { dialog, _ -> dialog.cancel() }

        // Showing Alert Message
        alertDialog.show()
    }

    override fun onBind(arg0: Intent): IBinder? { // intent
        return null
    }

    override fun onLocationChanged(location: Location) {
        Companion.latitude = location.latitude
        Companion.longitude = location.longitude
    }

    @Deprecated("Deprecated in Java")
    override fun onStatusChanged(arg0: String, status: Int, extras: Bundle) { // provider
    }

    override fun onProviderEnabled(arg0: String) { // provider
    }

    override fun onProviderDisabled(arg0: String) { // provider
    }

    companion object {
        var location: Location? = null
        var latitude = 0.0
        var longitude = 0.0
    }
}