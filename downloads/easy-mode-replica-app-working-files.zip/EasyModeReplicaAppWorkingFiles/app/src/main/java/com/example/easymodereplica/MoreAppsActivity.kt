package com.example.easymodereplica

import android.app.Activity
import android.app.ProgressDialog
import android.content.ActivityNotFoundException
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.graphics.drawable.Drawable
import android.os.Bundle
import android.os.Handler
import android.view.View
import android.widget.AdapterView.OnItemClickListener
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import java.util.Collections


open class MoreAppsActivity : Activity(), View.OnClickListener {
    // takes ages to load and sort listView which could easily be mistaken for a crash so
    // I corrected by running ListAppsActivityPreStart first to show a please wait dialog box
    private var packageManager: PackageManager? = null
    private var mapIndex: MutableMap<String, Int?>? = null
    private var simpleList: ListView? = null
    private var listPackageLabels = ArrayList<String>()
    private var listPackageNames = ArrayList<String>()
    private var listIcons = ArrayList<Drawable>()
    private var listIndex = ArrayList<String>()
    private val handler = Handler()

    //    boolean AppsListIsOpenTag;
    public override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_more_apps)
        simpleList = findViewById(R.id.simpleListView)
        packageManager = getPackageManager() // needed here
        val pd = ProgressDialog.show(this, "Populating List", "Please wait...", true)
        pd.setCancelable(true)


    //  delay code needed to allow enough time to draw the please wait dialog box
        handler.postDelayed({ // this code will be executed after 0.5 seconds
            createAppsList()
            displayFastIndex() // displays fast index on right
            pd.cancel()
        }, 500)
    }

    private fun createAppsList() {
        val listOfApps = packageManager!!.getInstalledApplications(PackageManager.GET_META_DATA)
        Collections.sort(
            listOfApps,
            ApplicationInfo.DisplayNameComparator(packageManager)
        ) // sorts listOfApps alphabetically
        for (appInfo in listOfApps) {
            try {
                if (null != packageManager!!.getLaunchIntentForPackage(appInfo.packageName)) {
                    listPackageLabels.add(appInfo.loadLabel(packageManager!!).toString())
                    listPackageNames.add(appInfo.packageName)
                    listIcons.add(appInfo.loadIcon(packageManager))
                    listIndex.add(appInfo.loadLabel(packageManager!!).toString())
                    //                    strLaunchActivity.add(packageManager.getLaunchIntentForPackage(appInfo.packageName));
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }

//        Collections.sort(listIndex, new AlphbeticalListSorter()); // previously sorted above, otherwise sort the lists here


        // Create new list a and add #
        val a: MutableList<String> = ArrayList()
        a.add("#")


        // New index list containing a union b
        val union: MutableList<String> = ArrayList(a)
        union.addAll(listIndex) // (list4 = b)
        val aToZIndex = union.toTypedArray<String>()
        createFastIndex(aToZIndex) // gets items first_letter to make alphabetical index
        val applicationAdapter =
            ApplicationAdapter(applicationContext, listPackageLabels, listIcons)
        simpleList!!.adapter = applicationAdapter
        simpleList!!.onItemClickListener = OnItemClickListener { parent, view, position, id ->
            //            Toast.makeText(ListAppsActivity.this, "Clicked", Toast.LENGTH_LONG).show();
//            Toast.makeText(ListAppsActivity.this, A_Z_names.get(position), Toast.LENGTH_SHORT).show();
            onListItemClick(parent as ListView, view, position, id) // starts apps on click
        }
    }

    //    @Override
    //    public boolean onCreateOptionsMenu(Menu menu) {
    //        getMenuInflater().inflate(R.menu.menu, menu);
    //        return true;
    //    }

    override fun onPointerCaptureChanged(hasCapture: Boolean) {}
    inner class AlphbeticalListSorter : Comparator<String> {
        override fun compare(s1: String, s2: String): Int {
            return s1.compareTo(s2, ignoreCase = true)
        }
    }

    private fun createFastIndex(preIndex2: Array<String>) { // makes fast scroll index from string
        mapIndex = LinkedHashMap()
        for (i in preIndex2.indices) {
            val preIndex1 = preIndex2[i]
            val index = preIndex1.substring(0, 1)
            if ((mapIndex as LinkedHashMap<String, Int?>).get(index) == null) (mapIndex as LinkedHashMap<String, Int?>)[index] = i - 1 //-1 to allow for addition of #
        }
    }

    private fun displayFastIndex() { // displays fast scroll index characters on right
        val indexLayout = findViewById<LinearLayout>(R.id.side_index)
        var textView: TextView
        val indexList: List<String> = ArrayList(
            mapIndex!!.keys
        )
        for (index in indexList) {
            textView = layoutInflater.inflate(
                R.layout.side_index_item, null
            ) as TextView
            textView.text = index
            textView.setOnClickListener(this)
            indexLayout.addView(textView)
        }
    }

    override fun onClick(view: View) {
        val selectedIndex = view as TextView
        simpleList!!.setSelection(mapIndex!![selectedIndex.text]!!)
    }

    private fun onListItemClick(l: ListView?, view: View?, position: Int, id: Long) {
//        super.onListItemClick(l, view, position, id);
        val app = listPackageNames[position]
        try {
            val intent = packageManager
                ?.getLaunchIntentForPackage(app)
            intent?.let { startActivity(it) }

            Toast.makeText(this@MoreAppsActivity, "Opening $intent", Toast.LENGTH_LONG).show()

        } catch (e: ActivityNotFoundException) {
            Toast.makeText(
                this@MoreAppsActivity, e.message,
                Toast.LENGTH_LONG
            ).show()
        } catch (e: Exception) {
            Toast.makeText(
                this@MoreAppsActivity, e.message,
                Toast.LENGTH_LONG
            ).show()
        }
    }

    override fun onStart() {
        super.onStart()
        //        Toast.makeText(getApplicationContext(), "onStart called", Toast.LENGTH_LONG).show();
    }

    override fun onResume() {
        super.onResume()
        //        Toast.makeText(getApplicationContext(), "onResumed called", Toast.LENGTH_LONG).show();
    }

    override fun onPause() {
        super.onPause()
        //        Toast.makeText(getApplicationContext(), "onPause called", Toast.LENGTH_LONG).show();
    }

    override fun onStop() {
        super.onStop()
        //        Toast.makeText(getApplicationContext(), "onStop called", Toast.LENGTH_LONG).show();
    }
}