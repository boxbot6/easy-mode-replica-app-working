package com.example.easymodereplica

import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.location.Location
import android.location.LocationManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.CalendarContract
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONException
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.concurrent.Executors


class GetWeatherActivity : AppCompatActivity() {
    private val myExecutor = Executors.newSingleThreadExecutor()
    private val myHandler = Handler(Looper.getMainLooper())

    // tags
    private var firstRunTag = true
    private var mainLayoutIsOpenTag = false
    private var settingsLayoutIsOpenTag = false
    private var moreAppsIsOpenTag = false
    private var gpsPermissionIsGivenTag = false
    private var locationPermissionIsGivenTag = false
    private var enterCityButtonPressedTag = false
    private var allowLocationButtonPressedTag = false
    private var nightTag = false

    // strings
    private var clockIntentText = "com.sec.android.app.clockpackage, com.sec.android.app.clockpackage.ClockPackage"
    private var locationIntentText = "com.example.easymodereplica.MainActivity"
    private var weatherIntentText = "https://www.bbc.co.uk/weather/4076598"
    private var dateUri = CalendarContract.CONTENT_URI.buildUpon().appendPath("time").build()
    private var dateIntentText = dateUri.toString() // created this string from above uri because it contains special character (")
    private var apiKey: String? = "73cbebdd0322acd49bda6ede059b2b18"
    private var logsButtonIntentText = "com.example.easymodereplica.LogsActivity"
    private var moreAppsButtonIntentText = "com.example.easymodereplica.MoreAppsActivity"
    private var homeButtonIntentText = "(Not Available)" // "com.easy_mode_replica.HomeButtonActivity"
    private var homeButtonLongPressIntentText = "(Not Available)" // "com.easy_mode_replica.HomeButtonLongPressActivity"
    private var holder: String? = null
    private var locationJSON: String? = null
    private var temperature: String? = null
    private var description: String? = null
    private var updatedAtFormatted: String? = null
    private var cityUserInput: String? = ""
    private var city: EditText? = null
    private var sunrise: Long = 0
    private var sunset: Long = 0
    private var updatedAt: Long = 0
    private lateinit var locationManager: LocationManager
    private val location: Location? = null
    private var latitude = 0.0
    private var longitude = 0.0
    private var runnableUserSet: Runnable? = null
    private var runnableGPSSet: Runnable? = null
    private var delay = 180000 // update delay (1000 per second, 900000 = 15mins);
    private var context: Context? = null


    public override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        apiWeatherCall()
    }

    private fun apiWeatherCall() {

        onPreExecute()

        myExecutor.execute {

            // Create class object
            val gps = GPSTracker(this@GetWeatherActivity)
            val latitude = gps.latitude
            val longitude = gps.longitude

            if (allowLocationButtonPressedTag) {
                val result = HttpRequest.executeGet("https://api.openweathermap.org/data/2.5/weather?lat=$latitude&lon=$longitude&units=metric&appid=$apiKey").toString()
            } else {
                val result = HttpRequest.executeGet("https://api.openweathermap.org/data/2.5/weather?q=$cityUserInput&units=metric&appid=$apiKey").toString()

                myHandler.post {

                    try {
                        // create JSON objects from the API response
                        val jsonObj = JSONObject(result)
                        val main = jsonObj.getJSONObject("main")
                        val sys = jsonObj.getJSONObject("sys")
                        val weather = jsonObj.getJSONArray("weather").getJSONObject(0)

                        // create variables using strings and data from the JSON object
                        val locationJSON = jsonObj.getString("name") // + ", " + sys.getString("country");
                        val temperature = String.format("%.0f", main.getDouble("temp")) + "°C"
                        val description = weather.getString("description") // String icon = weather.getString("main");
                        val sunrise = sys.getLong("sunrise")
                        val sunset = sys.getLong("sunset")
                        val updatedAt = jsonObj.getLong("dt")
                        val updatedAtFormatted = "Updated:   " + SimpleDateFormat("HH:mm   dd/MM/yy", Locale.ENGLISH).format(updatedAt * 1000)

                        // save values
                        val sharedSettings = getSharedPreferences("Shared_Settings", 0)
                        val editor = sharedSettings.edit()
                        editor.putString("temperature", temperature)
                        editor.putString("description", description)
                        editor.putBoolean("nightTag", nightTag)
                        editor.putLong("sunrise", sunrise)
                        editor.putLong("sunset", sunset)
                        editor.putLong("updatedAt", updatedAt)
                        editor.putString("updatedAtFormatted", updatedAtFormatted)
                        editor.putString("locationJSON", locationJSON)
                        editor.putString("userCity", cityUserInput)
                        editor.putBoolean("allowLocationButtonPressedTag", allowLocationButtonPressedTag)
                        editor.apply()

                    } catch (e: JSONException) { // if not found, possibly if empty or if userCity?
                        if (!allowLocationButtonPressedTag && cityUserInput == "") {
                            Toast.makeText(this@GetWeatherActivity, "Please Set Location in App", Toast.LENGTH_SHORT).show()
                        } else {
                            Toast.makeText(this@GetWeatherActivity, "Oops, Unable to get data from Openweathermap!", Toast.LENGTH_SHORT).show()
                        }
                    }
                    postUpdateWeatherTask()
                }
            }
        }
 //       return TODO("Provide the return value")
    }


    private fun onPreExecute() {
        // load values
        val sharedSettings = getSharedPreferences("Shared_Settings", 0)
//        val editor = sharedSettings.edit()
        firstRunTag = sharedSettings.getBoolean("firstRunTag", firstRunTag)
        enterCityButtonPressedTag = sharedSettings.getBoolean("enterCityButtonPressedTag", enterCityButtonPressedTag)
        allowLocationButtonPressedTag = sharedSettings.getBoolean("allowLocationButtonPressedTag", allowLocationButtonPressedTag)
        cityUserInput = sharedSettings.getString("userCity", cityUserInput)
        nightTag = sharedSettings.getBoolean("nightTag", nightTag)
        mainLayoutIsOpenTag = sharedSettings.getBoolean("mainLayoutIsOpenTag", mainLayoutIsOpenTag)
        settingsLayoutIsOpenTag = sharedSettings.getBoolean("settingsLayoutIsOpenTag", settingsLayoutIsOpenTag)
        locationJSON = sharedSettings.getString("locationJSON", locationJSON)
        apiKey = sharedSettings.getString("API_keyText", apiKey)
    }

    private fun postUpdateWeatherTask() {
        // load values
        val sharedSettings = getSharedPreferences("Shared_Settings", 0)
        val editor = sharedSettings.edit()
        temperature = sharedSettings.getString("temperature", temperature)
        description = sharedSettings.getString("description", description)
        nightTag = sharedSettings.getBoolean("nightTag", nightTag)
        sunrise = sharedSettings.getLong("sunrise", sunrise)
        sunset = sharedSettings.getLong("sunset", sunset)
        updatedAt = sharedSettings.getLong("updatedAt", updatedAt)
        updatedAtFormatted = sharedSettings.getString("updatedAtFormatted", updatedAtFormatted)
        locationJSON = sharedSettings.getString("locationJSON", locationJSON)
        cityUserInput = sharedSettings.getString("userCity", cityUserInput)
        allowLocationButtonPressedTag = sharedSettings.getBoolean("allowLocationButtonPressedTag", allowLocationButtonPressedTag)

        // night tag
        nightTag = updatedAt < sunrise || updatedAt >= sunset
        if ("Globe".equals(locationJSON, ignoreCase = true)) {
            locationJSON = "Not Available"
            temperature = ""
            description = ""
        }
        if ("Greater London".equals(locationJSON, ignoreCase = true)) {
            locationJSON = "London"
        }

        // save values
        editor.putString("temperature", temperature)
        editor.putString("description", description)
        editor.putBoolean("nightTag", nightTag)
        editor.putLong("sunrise", sunrise)
        editor.putLong("sunset", sunset)
        editor.putLong("updatedAt", updatedAt)
        editor.putString("updatedAtFormatted", updatedAtFormatted)
        editor.putString("locationJSON", locationJSON)
        editor.putString("userCity", cityUserInput)
        editor.putBoolean("allowLocationButtonPressedTag", allowLocationButtonPressedTag)
        editor.apply()

        updateWidget()
    }

    private fun updateWidget() { // send intent broadcast to widget from this activity:
        val intent = Intent(this, Widget1Activity::class.java)
        intent.setAction(AppWidgetManager.ACTION_APPWIDGET_UPDATE)
        // Use an array and EXTRA_APPWIDGET_IDS instead of AppWidgetManager.EXTRA_APPWIDGET_ID,
        // since it seems the onUpdate() is only fired on that:
        val ids = AppWidgetManager.getInstance(application)
            .getAppWidgetIds(ComponentName(application, Widget1Activity::class.java))
        intent.putExtra(AppWidgetManager.EXTRA_APPWIDGET_IDS, ids)
        sendBroadcast(intent)
    }

    companion object {
        private const val requestLocation = 1
    }
}
