package com.example.easymodereplica

import android.app.Activity
import android.appwidget.AppWidgetManager
import android.content.Intent
import android.os.Bundle


class WidgetConfigActivity : Activity() {
    private var widgetFirstRunTag = true

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val sharedSettings = getSharedPreferences("Shared_Settings", 0)
        val editor = sharedSettings.edit()
        widgetFirstRunTag = sharedSettings.getBoolean("widgetFirstRunTag", widgetFirstRunTag)

        if (widgetFirstRunTag) {
            val startIntent = Intent(this, MainActivity::class.java)
            startIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            this.startActivity(startIntent)
            widgetFirstRunTag = false
            editor.putBoolean("widgetFirstRunTag", false)
            editor.apply()
        }
        showAppWidget()
    }


    private var appWidgetId = 0
    private fun showAppWidget() {
        appWidgetId = AppWidgetManager.INVALID_APPWIDGET_ID

        // retrieve the App Widget ID from the Intent that launched the Activity
        val intent = intent
        val extras = intent.extras
        if (extras != null) {
            appWidgetId = extras.getInt(
                AppWidgetManager.EXTRA_APPWIDGET_ID,
                AppWidgetManager.INVALID_APPWIDGET_ID)

            // if the intent does not have a widget ID, then call finish()
            if (appWidgetId == AppWidgetManager.INVALID_APPWIDGET_ID) {
                finish()
            }

            // create the return intent
            val resultValue = Intent()

            // pass the original appWidgetId
            resultValue.putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, appWidgetId)

            // set the results from the configuration activity
            setResult(RESULT_OK, resultValue)

            // finish the activity
            finish()
        }
    }
}