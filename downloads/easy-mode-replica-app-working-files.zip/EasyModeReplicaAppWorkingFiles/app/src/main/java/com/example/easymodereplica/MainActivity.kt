package com.example.easymodereplica

import android.Manifest
import android.app.AlertDialog
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Criteria
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.AsyncTask
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.CalendarContract
import android.provider.Settings
import android.text.Editable
import android.text.TextUtils
import android.text.TextWatcher
import android.view.View
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.content.pm.ShortcutInfoCompat
import androidx.core.content.pm.ShortcutManagerCompat
import androidx.core.graphics.drawable.IconCompat
import com.example.easymodereplica.HttpRequest.executeGet
import org.json.JSONException
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Locale
import kotlin.system.exitProcess


open class MainActivity : AppCompatActivity(), LocationListener, View.OnClickListener {

// create values
    // api key (put your openweathermap key here)
    private var apiKey: String? = "73cbebdd0322acd49bda6ede059b2b18"

    // display text
    private var updatedAtTM: TextView? = null
    private var latitudeTM: TextView? = null
    private var longitudeTM: TextView? = null
    private var locationTM: TextView? = null
    private var updatedAtTS: TextView? = null
    private var locationTS: TextView? = null
    private var temperatureTS: TextView? = null
    private var descriptionTS: TextView? = null

    // checkboxes
    private var clockTick: CheckBox? = null
    private var locationTick: CheckBox? = null
    private var weatherTick: CheckBox? = null
    private var updateTick: CheckBox? = null
    private var dateTick: CheckBox? = null
    private var logsTick: CheckBox? = null
    private var moreAppsTick: CheckBox? = null
    private var homeButtonTick: CheckBox? = null
    private var homeButtonLongPressTick: CheckBox? = null

    // active tags
    private var clockTouchActive = false
    private var locationTouchActive = false
    private var weatherTouchActive = false
    private var dateTouchActive = false
    private var updateTouchActive = false
    private var logsButtonTouchActive = false
    private var moreAppsButtonTouchActive = false
    private var homeButtonTouchActive = false
    private var homeButtonLongPressTouchActive = false

    // tags
    private var firstRunTag = true
    private var mainLayoutIsOpenTag = false
    private var settingsLayoutIsOpenTag = false
    private var moreAppsIsOpenTag = false
    private var gpsPermissionIsGivenTag = false
    private var locationPermissionIsGivenTag = false
    private var enterCityButtonPressedTag = false
    private var allowLocationButtonPressedTag = false
    private var nightTag = false

    // strings
    private var clockIntentText = "com.google.android.deskclock, com.android.deskclock.DeskClock"
//    private var clockIntentText: String? = "com.google.android.deskclock, com.android.deskclock.DeskClock"
//    private var clockIntentText: String? = "com.sec.android.app.clockpackage, com.sec.android.app.clockpackage.ClockPackage"
    private var locationIntentText: String? = "com.example.easymodereplica.MainActivity" // "com.easy_mode_replica.MainActivity"
    private var weatherIntentText: String? = "https://www.bbc.co.uk/weather/4076598"
    private var dateUri: Uri = CalendarContract.CONTENT_URI.buildUpon().appendPath("time").build()
    private var dateIntentText: String? = dateUri.toString() // created this string from above uri because it contains special character (")
    private var logsButtonIntentText: String? = "com.example.easymodereplica.LogsActivity"
    private var moreAppsButtonIntentText: String? = "com.example.easymodereplica.MoreAppsActivity"
    private var homeButtonIntentText: String? = "(Not Available)" // "com.easy_mode_replica.HomeButtonActivity"
    private var homeButtonLongPressIntentText: String? = "(Not Available)" // "com.easy_mode_replica.HomeButtonLongPressActivity"
    private var holder: String? = null
    private var locationJSON: String? = null
    private var temperature: String? = null
    private var description: String? = null
    private var updatedAtFormatted: String? = null
    private var cityUserInput: String? = ""
    private var city: EditText? = null
    private var sunrise: Long = 0
    private var sunset: Long = 0
    private var updatedAt: Long = 0
    private var criteria: Criteria? = null
    private lateinit var locationManager: LocationManager
    private val delay: Long = 20000 // update delay (1000 per second, 900000 = 15mins);
    private val shortcutIconAddedTag = "shortcutIconAddedTag"

    private val handlerUserSet = Handler(Looper.getMainLooper())
    private var runnableUserSet = Runnable {
        // Do what ever you want
    }
// use    handlerUserSet.postDelayed(runnableUserSet, delay)
// use    handlerUserSet.removeCallbacks(runnableUserSet)

    private val handlerGPSSet = Handler(Looper.getMainLooper())
    private var runnableGPSSet = Runnable {
        // Do what ever you want
    }
// use    handlerGPSSet.postDelayed(runnableGPSSet, delay)
// use    handlerGPSSet.removeCallbacks(runnableGPSSet)


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        addShortcutIcon(this)

        loadValues()

/*
        // buttons
        val btnExitMain = findViewById<ImageView>(R.id.buttonExitMain)
        btnExitMain.setOnClickListener {


            // save checkbox values
            clockTick?.isChecked?.let { saveCheckboxValues(it, "clockTick") }
            locationTick?.isChecked?.let { saveCheckboxValues(it, "locationTick") }
            weatherTick?.isChecked?.let { saveCheckboxValues(it, "weatherTick") }
            updateTick?.isChecked?.let { saveCheckboxValues(it, "updateTick") }
            dateTick?.isChecked?.let { saveCheckboxValues(it, "dateTick") }
            logsTick?.isChecked?.let { saveCheckboxValues(it, "logsTick") }
            moreAppsTick?.isChecked?.let { saveCheckboxValues(it, "moreAppsTick") }
            homeButtonTick?.isChecked?.let { saveCheckboxValues(it, "homeButtonTick") }
            homeButtonLongPressTick?.isChecked?.let { saveCheckboxValues(it, "homeButtonLongPressTick") }


            saveValues()

            finish()
            exitProcess(0)



        // two views included on same layout to avoid passing values, below sets which view is visible
        findViewById<View>(R.id.mainItemsContainer).visibility = View.VISIBLE
        mainLayoutIsOpenTag = true
        findViewById<View>(R.id.settingsItemsContainer).visibility = View.GONE
        settingsLayoutIsOpenTag = false

       --------

        fun exit(view: View?) {
        finish()
        exitProcess(0)
    }

        }

        val btnSetCity = findViewById<Button>(R.id.buttonSetCity)
        btnSetCity.setOnClickListener {
            enterCityButtonPressed()
        }

        val btnAllowAccess = findViewById<Button>(R.id.buttonAllowAccess)
        btnAllowAccess.setOnClickListener {
            allowLocationButtonPressed()
        }

        val btnOpenSettings = findViewById<Button>(R.id.buttonOpenSettings)
        btnOpenSettings.setOnClickListener {
            val intent = Intent(this, SettingsActivity::class.java)
            startActivity(intent)
        }

 */




        // two views included on same layout to avoid passing values, below sets which view is visible
        findViewById<View>(R.id.mainItemsContainer).visibility = View.VISIBLE
        mainLayoutIsOpenTag = true
        findViewById<View>(R.id.settingsItemsContainer).visibility = View.GONE
        settingsLayoutIsOpenTag = false


        // save values changed within this task
        val sharedSettings = getSharedPreferences("Shared_Settings", 0)
        val editor = sharedSettings.edit()
        latitudeTM = findViewById(R.id.showLatitudeMain)
        longitudeTM = findViewById(R.id.showLongitudeMain)
        locationTM = findViewById(R.id.showLocationMain)
        updatedAtTM = findViewById(R.id.updatedAtMain)
//        val btnSetCity = findViewById<Button>(R.id.buttonSetCity)
        val btnAllowAccess = findViewById<Button>(R.id.buttonAllowAccess)
        city = findViewById(R.id.showEditCity)
        city?.setText(cityUserInput.toString())

        locationManager = getSystemService(LOCATION_SERVICE) as LocationManager
//        val provider = locationManager!!.getBestProvider(Criteria(), false)

        // checks if GPS permission is granted
        gpsPermissionIsGivenTag = locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)

        // checks if location permission is granted
        locationPermissionIsGivenTag = ContextCompat.checkSelfPermission(
            this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED

        if (enterCityButtonPressedTag) {
            allowLocationButtonPressedTag = false
            // pause updates
            handlerGPSSet.removeCallbacks(runnableGPSSet)
            handlerUserSet.removeCallbacks(runnableUserSet)
            // start updates
            handlerUserSet.postDelayed(runnableUserSet, delay) // starts regular updates
            latitudeTM?.text = null
            longitudeTM?.text = null
            locationTM?.text = getString(R.string.using_user_entered_city_of, locationJSON)
        } else if (allowLocationButtonPressedTag && locationPermissionIsGivenTag && gpsPermissionIsGivenTag) {
            enterCityButtonPressedTag = false
            // pause updates
            handlerUserSet.removeCallbacks(runnableUserSet)
            handlerGPSSet.removeCallbacks(runnableGPSSet)
            // start updates
            handlerGPSSet.postDelayed((runnableGPSSet), delay) // starts regular updates
            if ((holder == null) or (locationJSON == null) or (latitude == 0.0)) {
                latitudeTM?.text = getString(R.string.getting_latitude_please_wait)
                longitudeTM?.text = getString(R.string.getting_longitude_please_wait)
            } else {
                latitudeTM?.text = buildString {
                    append("Lat:  ")
                    append(latitude)
                }
                longitudeTM?.text = buildString {
                    append("Long:  ")
                    append(longitude)
                }
            }
            locationTM?.text = getString(R.string.using_gps_located_city_of, locationJSON)
        } else {
            // pause updates
            handlerUserSet.removeCallbacks(runnableUserSet)
            handlerGPSSet.removeCallbacks(runnableGPSSet)
            latitudeTM?.text = null
            longitudeTM?.text = null
            locationTM?.text = null
        }

        // set text for buttons
        if (gpsPermissionIsGivenTag && locationPermissionIsGivenTag) {
            if (allowLocationButtonPressedTag) {
                btnAllowAccess.text = getString(R.string.access_to_phone_location_is_allowed)
            } else {
                btnAllowAccess.text = getString(R.string.access_to_phone_location_is_allowed_press_to_use)
            }
        } else {
            btnAllowAccess.text = getString(R.string.allow_access_to_phone_location)
        }

        editor.apply()
        saveValues()
    }


    // Creates shortcut on Android widget screen
    open fun addShortcutIcon(context: Context?) {

        // Checking if ShortCut was already added
        val sharedPreferences = getPreferences(MODE_PRIVATE)
        val shortcutWasAlreadyAdded = sharedPreferences.getBoolean(shortcutIconAddedTag, false)
        if (shortcutWasAlreadyAdded) return

        if (ShortcutManagerCompat.isRequestPinShortcutSupported(context!!)) {
            val shortcutInfo = ShortcutInfoCompat.Builder(context, "#1")
                .setIntent(Intent(context, MainActivity::class.java).setAction(Intent.ACTION_MAIN)) // !!! intent's action must be set on oreo
                .setShortLabel("Easy Mode Replica")
                .setIcon(IconCompat.createWithResource(context, R.drawable.ic_launcher))
                .build()
            ShortcutManagerCompat.requestPinShortcut(context, shortcutInfo, null)
        } else {
            // Shortcut is not supported by your launcher
        }

        // Remembering that ShortCut was already added
        val editor = sharedPreferences.edit()
        editor.putBoolean(shortcutIconAddedTag, true)
        editor.apply()
    }

    private fun onCreateForSettingsLayout() {
        loadValues()
        setContentView(R.layout.activity_main)  // activity_settings)
        if (settingsLayoutIsOpenTag) {
            findViewById<View>(R.id.settingsItemsContainer).visibility = View.VISIBLE
            findViewById<View>(R.id.mainItemsContainer).visibility = View.GONE
            mainLayoutIsOpenTag = false
            settingsLayoutIsOpenTag = true
        }


        // save values changed later within onCreate
        val sharedSettings = getSharedPreferences("Shared_Settings", 0)
        val editor = sharedSettings.edit()
        locationTS = findViewById(R.id.showLocationSettings)
        temperatureTS = findViewById(R.id.temperatureSettings)
        descriptionTS = findViewById(R.id.descriptionSettings)
        updatedAtTS = findViewById(R.id.updatedAtSettings)
        locationManager = getSystemService(LOCATION_SERVICE) as LocationManager
//        val provider = locationManager?.getBestProvider(Criteria(), false)


        // checks if GPS permission is granted
        gpsPermissionIsGivenTag = locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)


        // checks if location permission is granted
        locationPermissionIsGivenTag = ContextCompat.checkSelfPermission(
            this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED

        if ((enterCityButtonPressedTag) or (allowLocationButtonPressedTag && gpsPermissionIsGivenTag && locationPermissionIsGivenTag)) {
            locationTS?.text = locationJSON
        } else {
            locationTS?.text = null
        }


        // set up update for the editable text inputs
        val editTextClock = findViewById<EditText>(R.id.editTextClockIntent)
        editTextClock.setText(sharedSettings.getString(clockIntentText, clockIntentText))
        editTextClock.addTextChangedListener(object : TextWatcher {
            override fun onTextChanged(ci: CharSequence, start: Int, before: Int, count: Int) {}
            override fun beforeTextChanged(ci: CharSequence, start: Int, count: Int, after: Int) {}
            override fun afterTextChanged(ci: Editable) {
                sharedSettings.edit().putString(clockIntentText, ci.toString()).apply()
            }
        })
        val editTextLocation = findViewById<EditText>(R.id.editTextLocationIntent)
        editTextLocation.setText(sharedSettings.getString(locationIntentText, locationIntentText))
        editTextLocation.addTextChangedListener(object : TextWatcher {
            override fun onTextChanged(li: CharSequence, start: Int, before: Int, count: Int) {}
            override fun beforeTextChanged(li: CharSequence, start: Int, count: Int, after: Int) {}
            override fun afterTextChanged(li: Editable) {
                sharedSettings.edit().putString(locationIntentText, li.toString()).apply()
            }
        })
        val editTextWeather = findViewById<EditText>(R.id.editTextWeatherIntent)
        editTextWeather.setText(sharedSettings.getString(weatherIntentText, weatherIntentText))
        editTextWeather.addTextChangedListener(object : TextWatcher {
            override fun onTextChanged(wi: CharSequence, start: Int, before: Int, count: Int) {}
            override fun beforeTextChanged(wi: CharSequence, start: Int, count: Int, after: Int) {}
            override fun afterTextChanged(wi: Editable) {
                sharedSettings.edit().putString(weatherIntentText, wi.toString()).apply()
            }
        })
        val editTextDate = findViewById<EditText>(R.id.editTextDateIntent)
        editTextDate.setText(sharedSettings.getString(dateIntentText, dateIntentText))
        editTextDate.addTextChangedListener(object : TextWatcher {
            override fun onTextChanged(di: CharSequence, start: Int, before: Int, count: Int) {}
            override fun beforeTextChanged(di: CharSequence, start: Int, count: Int, after: Int) {}
            override fun afterTextChanged(di: Editable) {
                sharedSettings.edit().putString(dateIntentText, di.toString()).apply()
            }
        })
        val editTextApiKey = findViewById<EditText>(R.id.editTextApi_key)
        editTextApiKey.setText(sharedSettings.getString(apiKey, apiKey))
        editTextApiKey.addTextChangedListener(object : TextWatcher {
            override fun onTextChanged(ai: CharSequence, start: Int, before: Int, count: Int) {}
            override fun beforeTextChanged(ai: CharSequence, start: Int, count: Int, after: Int) {}
            override fun afterTextChanged(ai: Editable) {
                sharedSettings.edit().putString(apiKey, ai.toString()).apply()
            }
        })
        val editTextLogsButton = findViewById<EditText>(R.id.editTextLogsButtonIntent)
        editTextLogsButton.setText(sharedSettings.getString(logsButtonIntentText, logsButtonIntentText))
        editTextLogsButton.addTextChangedListener(object : TextWatcher {
            override fun onTextChanged(lgi: CharSequence, start: Int, before: Int, count: Int) {}
            override fun beforeTextChanged(lgi: CharSequence, start: Int, count: Int, after: Int) {}
            override fun afterTextChanged(lgi: Editable) {
                sharedSettings.edit().putString(logsButtonIntentText, lgi.toString()).apply()
            }
        })
        val editTextMoreAppsButton = findViewById<EditText>(R.id.editTextMoreAppsButtonIntent)
        editTextMoreAppsButton.setText(sharedSettings.getString(moreAppsButtonIntentText, moreAppsButtonIntentText))
        editTextMoreAppsButton.addTextChangedListener(object : TextWatcher {
            override fun onTextChanged(mi: CharSequence, start: Int, before: Int, count: Int) {}
            override fun beforeTextChanged(mi: CharSequence, start: Int, count: Int, after: Int) {}
            override fun afterTextChanged(mi: Editable) {
                sharedSettings.edit().putString(moreAppsButtonIntentText, mi.toString()).apply()
            }
        })
        val editTextHomeButton = findViewById<EditText>(R.id.editTextHomeButtonIntent)
        editTextHomeButton.setText(sharedSettings.getString(homeButtonIntentText, homeButtonIntentText))
        editTextHomeButton.addTextChangedListener(object : TextWatcher {
            override fun onTextChanged(hi: CharSequence, start: Int, before: Int, count: Int) {}
            override fun beforeTextChanged(hi: CharSequence, start: Int, count: Int, after: Int) {}
            override fun afterTextChanged(hi: Editable) {
                sharedSettings.edit().putString(homeButtonIntentText, hi.toString()).apply()
            }
        })
        val editTextHomeButtonLongPress =
            findViewById<EditText>(R.id.editTextHomeButtonLongPressIntent)
        editTextHomeButtonLongPress.setText(sharedSettings.getString(homeButtonLongPressIntentText, homeButtonLongPressIntentText))
        editTextHomeButtonLongPress.addTextChangedListener(object : TextWatcher {
            override fun onTextChanged(hli: CharSequence, start: Int, before: Int, count: Int) {}
            override fun beforeTextChanged(hli: CharSequence, start: Int, count: Int, after: Int) {}
            override fun afterTextChanged(hli: Editable) {
                sharedSettings.edit().putString(homeButtonLongPressIntentText, hli.toString())
                    .apply()
            }
        })


        // initiate views
        clockTick = findViewById(R.id.clockCheckBox)
        clockTick?.setOnClickListener(this)
        locationTick = findViewById(R.id.locationCheckBox)
        locationTick?.setOnClickListener(this)
        weatherTick = findViewById(R.id.weatherCheckBox)
        weatherTick?.setOnClickListener(this)
        updateTick = findViewById(R.id.updateCheckBox)
        updateTick?.setOnClickListener(this)
        dateTick = findViewById(R.id.dateCheckBox)
        dateTick?.setOnClickListener(this)
        logsTick = findViewById(R.id.logsCheckBox)
        logsTick?.setOnClickListener(this)
        moreAppsTick = findViewById(R.id.moreAppsCheckBox)
        moreAppsTick?.setOnClickListener(this)
        homeButtonTick = findViewById(R.id.homeButtonCheckBox)
        homeButtonTick?.setOnClickListener(this)
        homeButtonLongPressTick = findViewById(R.id.homeButtonLongPressCheckBox)
        homeButtonLongPressTick?.setOnClickListener(this)

        if (firstRunTag) { // sets these checkboxes to checked initially
            // code to run once
            locationTick?.isChecked = true
            locationTouchActive = true
            locationTick?.isChecked?.let { saveCheckboxValues(it, "locationTick") } // need this
            editor.putBoolean("locationTouchActive", locationTouchActive)
            updateTick?.isChecked = true
            updateTouchActive = true
            updateTick?.isChecked?.let { saveCheckboxValues(it, "updateTick") } // need this
            editor.putBoolean("updateTouchActive", locationTouchActive)
            logsTick?.isChecked = true
            logsButtonTouchActive = true
            logsTick?.isChecked?.let { saveCheckboxValues(it, "logsTick") } // need this
            editor.putBoolean("logsButtonTouchActive", logsButtonTouchActive)
            moreAppsTick?.isChecked = true
            moreAppsButtonTouchActive = true
            moreAppsTick?.isChecked?.let { saveCheckboxValues(it, "moreAppsTick") } // need this
            editor.putBoolean("moreAppsButtonTouchActive", moreAppsButtonTouchActive)
            editor.putBoolean("firstRunTag", false)
            editor.putBoolean("widgetFirstRunTag", false)
            editor.apply()
        }
        editor.commit()
        saveValues()
    }

    private fun loadValues() {

        // load values
        val sharedSettings = getSharedPreferences("Shared_Settings", 0)
        // val editor = Shared_Settings.edit()
        firstRunTag = sharedSettings.getBoolean("firstRunTag", firstRunTag)
        mainLayoutIsOpenTag = sharedSettings.getBoolean("mainLayoutIsOpenTag", mainLayoutIsOpenTag)
        settingsLayoutIsOpenTag = sharedSettings.getBoolean(" settingsLayoutIsOpenTag", settingsLayoutIsOpenTag)
        moreAppsIsOpenTag = sharedSettings.getBoolean("moreAppsIsOpenTag", moreAppsIsOpenTag)
        gpsPermissionIsGivenTag = sharedSettings.getBoolean("gpsPermissionIsGivenTag", gpsPermissionIsGivenTag)
        locationPermissionIsGivenTag = sharedSettings.getBoolean("locationPermissionIsGivenTag", locationPermissionIsGivenTag)
        enterCityButtonPressedTag = sharedSettings.getBoolean("enterCityButtonPressedTag", enterCityButtonPressedTag)
        allowLocationButtonPressedTag = sharedSettings.getBoolean("allowLocationButtonPressedTag", allowLocationButtonPressedTag)
        locationJSON = sharedSettings.getString("locationJSON", locationJSON)
        cityUserInput = sharedSettings.getString("userCity", cityUserInput)
        clockIntentText = sharedSettings.getString("clockIntentText", clockIntentText).toString()
        locationIntentText = sharedSettings.getString("locationIntentText", locationIntentText)
        weatherIntentText = sharedSettings.getString("weatherIntentText", weatherIntentText)
        dateIntentText = sharedSettings.getString("dateIntentText", dateIntentText)
        apiKey = sharedSettings.getString("API_keyText", apiKey)
        logsButtonIntentText = sharedSettings.getString("logsButtonIntentText", logsButtonIntentText)
        moreAppsButtonIntentText = sharedSettings.getString("moreAppsButtonIntentText", moreAppsButtonIntentText)
        homeButtonIntentText = sharedSettings.getString("homeButtonIntentText", homeButtonIntentText)
        homeButtonLongPressIntentText = sharedSettings.getString("homeButtonLongPressIntentText", homeButtonLongPressIntentText)
        clockTouchActive = sharedSettings.getBoolean("clockTouchActive", clockTouchActive)
        locationTouchActive = sharedSettings.getBoolean("locationTouchActive", locationTouchActive)
        weatherTouchActive = sharedSettings.getBoolean("weatherTouchActive", weatherTouchActive)
        updateTouchActive = sharedSettings.getBoolean("updateTouchActive", updateTouchActive)
        dateTouchActive = sharedSettings.getBoolean("dateTouchActive", dateTouchActive)
        logsButtonTouchActive = sharedSettings.getBoolean("logsButtonTouchActive", logsButtonTouchActive)
        moreAppsButtonTouchActive = sharedSettings.getBoolean("moreAppsButtonTouchActive", moreAppsButtonTouchActive)
        homeButtonTouchActive = sharedSettings.getBoolean("homeButtonTouchActive", homeButtonTouchActive)
        homeButtonLongPressTouchActive = sharedSettings.getBoolean("homeButtonLongPressTouchActive", homeButtonLongPressTouchActive)
    }

    private fun saveValues() {
        // save values
        val sharedSettings = getSharedPreferences("Shared_Settings", 0)
        val editor = sharedSettings.edit()
        editor.putBoolean("firstRunTag", firstRunTag)
        editor.putBoolean("mainLayoutIsOpenTag", mainLayoutIsOpenTag)
        editor.putBoolean("settingsLayoutIsOpenTag", settingsLayoutIsOpenTag)
        editor.putBoolean("moreAppsIsOpenTag", moreAppsIsOpenTag)
        editor.putBoolean("gpsPermissionIsGivenTag", gpsPermissionIsGivenTag)
        editor.putBoolean("locationPermissionIsGivenTag", locationPermissionIsGivenTag)
        editor.putBoolean("enterCityButtonPressedTag", enterCityButtonPressedTag)
        editor.putBoolean("allowLocationButtonPressedTag", allowLocationButtonPressedTag)
        editor.putString("locationJSON", locationJSON)
        editor.putString("userCity", cityUserInput)
        editor.putString("clockIntentText", clockIntentText)
        editor.putString("locationIntentText", locationIntentText)
        editor.putString("weatherIntentText", weatherIntentText)
        editor.putString("dateIntentText", dateIntentText)
        editor.putString("API_keyText", apiKey)
        editor.putString("logsButtonIntentText", logsButtonIntentText)
        editor.putString("moreAppsButtonIntentText", moreAppsButtonIntentText)
        editor.putString("homeButtonIntentText", homeButtonIntentText)
        editor.putString("homeButtonLongPressIntentText", homeButtonLongPressIntentText)
        editor.putBoolean("clockTouchActive", clockTouchActive)
        editor.putBoolean("locationTouchActive", locationTouchActive)
        editor.putBoolean("weatherTouchActive", weatherTouchActive)
        editor.putBoolean("updateTouchActive", updateTouchActive)
        editor.putBoolean("dateTouchActive", dateTouchActive)
        editor.putBoolean("logsButtonTouchActive", logsButtonTouchActive)
        editor.putBoolean("moreAppsButtonTouchActive", moreAppsButtonTouchActive)
        editor.putBoolean("homeButtonTouchActive", homeButtonTouchActive)
        editor.putBoolean("homeButtonLongPressTouchActive", homeButtonLongPressTouchActive)
        editor.apply()
    }


     override fun onClick(view: View) {
        when (view.id) {
            R.id.clockCheckBox -> clockTouchActive = clockTick?.isChecked == true
            R.id.locationCheckBox -> locationTouchActive = locationTick?.isChecked == true
            R.id.weatherCheckBox -> weatherTouchActive = weatherTick?.isChecked == true
            R.id.updateCheckBox -> updateTouchActive = updateTick?.isChecked == true
            R.id.dateCheckBox -> dateTouchActive = dateTick?.isChecked == true
            R.id.logsCheckBox -> logsButtonTouchActive = logsTick?.isChecked == true
            R.id.moreAppsCheckBox -> moreAppsButtonTouchActive = moreAppsTick?.isChecked == true
            R.id.homeButtonCheckBox -> homeButtonTouchActive = homeButtonTick?.isChecked == true
            R.id.homeButtonLongPressCheckBox -> homeButtonLongPressTouchActive = homeButtonLongPressTick?.isChecked == true
        }


        saveValues()
        // save other values
        val sharedSettings = getSharedPreferences("Shared_Settings", 0)
        val editor = sharedSettings.edit()
        locationTick?.isChecked?.let { saveCheckboxValues(it, "locationTick") } // need this
        updateTick?.isChecked?.let { saveCheckboxValues(it, "updateTick") } // need this
        logsTick?.isChecked?.let { saveCheckboxValues(it, "logsTick") } // need this
        moreAppsTick?.isChecked?.let { saveCheckboxValues(it, "moreAppsTick") } // need this
        editor.apply()
    }

    public override fun onPause() {
        super.onPause()

        // stop update handlers when activity paused;
        handlerUserSet.removeCallbacks(runnableUserSet)
        handlerGPSSet.removeCallbacks(runnableGPSSet)
        if (enterCityButtonPressedTag) {
            allowLocationButtonPressedTag = false
        }
        if (allowLocationButtonPressedTag) {
            enterCityButtonPressedTag = false
        }


        // save checkbox values
        clockTick?.isChecked?.let { saveCheckboxValues(it, "clockTick") }
        locationTick?.isChecked?.let { saveCheckboxValues(it, "locationTick") }
        weatherTick?.isChecked?.let { saveCheckboxValues(it, "weatherTick") }
        updateTick?.isChecked?.let { saveCheckboxValues(it, "updateTick") }
        dateTick?.isChecked?.let { saveCheckboxValues(it, "dateTick") }
        logsTick?.isChecked?.let { saveCheckboxValues(it, "logsTick") }
        moreAppsTick?.isChecked?.let { saveCheckboxValues(it, "moreAppsTick") }
        homeButtonTick?.isChecked?.let { saveCheckboxValues(it, "homeButtonTick") }
        homeButtonLongPressTick?.isChecked?.let { saveCheckboxValues(it, "homeButtonLongPressTick") }
        saveValues()
    }

    public override fun onResume() {
        super.onResume()
        loadValues()
        if (settingsLayoutIsOpenTag) {
            mainLayoutIsOpenTag = false
            setContentView(R.layout.activity_main)
            findViewById<View>(R.id.settingsItemsContainer).visibility = View.VISIBLE
            findViewById<View>(R.id.mainItemsContainer).visibility = View.GONE
            onCreateForSettingsLayout() // opens settings here and updates values
        }

        if (mainLayoutIsOpenTag) {
            settingsLayoutIsOpenTag = false
            setContentView(R.layout.activity_main)
            findViewById<View>(R.id.mainItemsContainer).visibility = View.VISIBLE
            findViewById<View>(R.id.settingsItemsContainer).visibility = View.GONE
        }


        // load checkbox ticked values // keep this below onCreateForSettingsLayout();
        clockTick?.isChecked = load("clockTick")
        locationTick?.isChecked = load("locationTick")
        weatherTick?.isChecked = load("weatherTick")
        updateTick?.isChecked = load("updateTick")
        dateTick?.isChecked = load("dateTick")
        logsTick?.isChecked = load("logsTick")
        moreAppsTick?.isChecked = load("moreAppsTick")
        homeButtonTick?.isChecked = load("homeButtonTick")
        homeButtonLongPressTick?.isChecked = load("homeButtonLongPressTick")
//        val btnSetCity = findViewById<Button>(R.id.buttonSetCity)
        val btnAllowAccess = findViewById<Button>(R.id.buttonAllowAccess)
        city = findViewById(R.id.showEditCity)
        city?.setText(cityUserInput.toString())
        locationManager = getSystemService(LOCATION_SERVICE) as LocationManager
//        val provider = locationManager!!.getBestProvider(Criteria(), false)


        // checks if GPS permission is granted
        gpsPermissionIsGivenTag = locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER) == true


        // checks if location permission is granted
        locationPermissionIsGivenTag = ContextCompat.checkSelfPermission(
            this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        if (enterCityButtonPressedTag) {
            allowLocationButtonPressedTag = false
            handlerGPSSet.removeCallbacks(runnableGPSSet)
            handlerUserSet.removeCallbacks(runnableUserSet) // recycles handler
            handlerUserSet.postDelayed(runnableUserSet, delay)

            latitudeTM?.text = null
            longitudeTM?.text = null
            locationTS?.text = locationJSON
            locationTM?.text = getString(R.string.using_user_entered_city_of, locationJSON) // userCity
        } else if (allowLocationButtonPressedTag && gpsPermissionIsGivenTag && locationPermissionIsGivenTag) {
            enterCityButtonPressedTag = false
            handlerUserSet.removeCallbacks(runnableUserSet)
            handlerGPSSet.removeCallbacks(runnableGPSSet) // recycles handler
            handlerGPSSet.postDelayed(runnableGPSSet, delay)

            if ((holder == null) or (locationJSON == null) or (latitude == 0.0)) {
                latitudeTM?.text = getString(R.string.getting_latitude_please_wait)
                longitudeTM?.text = getString(R.string.getting_longitude_please_wait)
                this.location
            } else {
                latitudeTM?.text = buildString {
                    append("Lat:  ")
                    append(latitude)
                }
                longitudeTM?.text = buildString {
                    append("Long:  ")
                    append(longitude)
                }
            }

            locationTS?.text = locationJSON
            locationTM?.text = getString(R.string.using_gps_located_city_of, locationJSON)
        } else {
            handlerUserSet.removeCallbacks(runnableUserSet)
            handlerGPSSet.removeCallbacks(runnableGPSSet)
            latitudeTM?.text = null
            longitudeTM?.text = null
            locationTS?.text = null
            locationTM?.text = null
        }


        // set text for buttons
        if (gpsPermissionIsGivenTag && locationPermissionIsGivenTag) {
            if (allowLocationButtonPressedTag) {
                btnAllowAccess.text = "ACCESS TO PHONE LOCATION IS ALLOWED"
            } else {
                btnAllowAccess.text = "ACCESS TO PHONE LOCATION IS ALLOWED (PRESS TO USE)"
            }
        } else {
            btnAllowAccess.text = "ALLOW ACCESS TO PHONE LOCATION"
        }
        saveValues()
        GetWeatherTask().execute()
    }

    private fun saveCheckboxValues(isChecked: Boolean, key: String) {

        // save values
        val sharedSettings = getSharedPreferences("Shared_Settings", 0)
        val editor = sharedSettings.edit()
        editor.putBoolean("firstRunTag", firstRunTag)
        editor.putBoolean("mainLayoutIsOpenTag", mainLayoutIsOpenTag)
        editor.putBoolean("settingsLayoutIsOpenTag", settingsLayoutIsOpenTag)
        editor.putBoolean("moreAppsIsOpenTag", moreAppsIsOpenTag)
        editor.putBoolean("gpsPermissionIsGivenTag", gpsPermissionIsGivenTag)
        editor.putBoolean("locationPermissionIsGivenTag", locationPermissionIsGivenTag)
        editor.putBoolean("enterCityButtonPressedTag", enterCityButtonPressedTag)
        editor.putBoolean("allowLocationButtonPressedTag", allowLocationButtonPressedTag)
        editor.putString("locationJSON", locationJSON)
        editor.putString("userCity", cityUserInput)
        editor.putBoolean("locationTouchActive", locationTouchActive)
        editor.putBoolean("logsButtonTouchActive", logsButtonTouchActive)
        editor.putBoolean("moreAppsButtonTouchActive", moreAppsButtonTouchActive)
        editor.putBoolean(key, isChecked)
        editor.apply()
    }

    private fun load(key: String): Boolean {
        // load values
        val sharedSettings = getSharedPreferences("Shared_Settings", 0)
//        val editor = Shared_Settings.edit()
        firstRunTag = sharedSettings.getBoolean("firstRunTag", firstRunTag)
        mainLayoutIsOpenTag = sharedSettings.getBoolean("mainLayoutIsOpenTag", mainLayoutIsOpenTag)
        settingsLayoutIsOpenTag = sharedSettings.getBoolean(" settingsLayoutIsOpenTag", settingsLayoutIsOpenTag)
        moreAppsIsOpenTag = sharedSettings.getBoolean("moreAppsIsOpenTag", moreAppsIsOpenTag)
        gpsPermissionIsGivenTag = sharedSettings.getBoolean("gpsPermissionIsGivenTag", gpsPermissionIsGivenTag)
        locationPermissionIsGivenTag = sharedSettings.getBoolean("locationPermissionIsGivenTag", locationPermissionIsGivenTag)
        enterCityButtonPressedTag = sharedSettings.getBoolean("enterCityButtonPressedTag", enterCityButtonPressedTag)
        allowLocationButtonPressedTag = sharedSettings.getBoolean("allowLocationButtonPressedTag", allowLocationButtonPressedTag)
        locationJSON = sharedSettings.getString("locationJSON", locationJSON)
        cityUserInput = sharedSettings.getString("userCity", cityUserInput)
        city?.setText(cityUserInput.toString())
        locationTouchActive = sharedSettings.getBoolean("locationTouchActive", locationTouchActive)
        logsButtonTouchActive = sharedSettings.getBoolean("logsButtonTouchActive", logsButtonTouchActive)
        moreAppsButtonTouchActive = sharedSettings.getBoolean("moreAppsButtonTouchActive", moreAppsButtonTouchActive)
        return sharedSettings.getBoolean(key, false)
    }

    // main activity buttons
    fun enterCityButtonPressed(view: View?) { // leave view: View? here

        // load values
        val sharedSettings = getSharedPreferences("Shared_Settings", 0)
        val editor = sharedSettings.edit()
        gpsPermissionIsGivenTag = sharedSettings.getBoolean("gpsPermissionIsGivenTag", gpsPermissionIsGivenTag)
        locationPermissionIsGivenTag = sharedSettings.getBoolean("locationPermissionIsGivenTag", locationPermissionIsGivenTag)
        enterCityButtonPressedTag = sharedSettings.getBoolean("enterCityButtonPressedTag", enterCityButtonPressedTag)
        allowLocationButtonPressedTag = sharedSettings.getBoolean("allowLocationButtonPressedTag", allowLocationButtonPressedTag)
//        val btnSetCity = findViewById<Button>(R.id.buttonSetCity)
        val btnAllowAccess = findViewById<Button>(R.id.buttonAllowAccess)

        // check if Wifi and mobile data are active first
        // Returns connection type. 0: none; 1: mobile data; 2: wifi; 3: vpn
        if (getConnectionType() != 0) {

            cityUserInput = city?.text.toString()
            if (TextUtils.isEmpty(cityUserInput)) {
                Toast.makeText(this,"Oops, Try entering a different location?", Toast.LENGTH_SHORT).show()
            } else {

                // set button pressed values
                allowLocationButtonPressedTag = false
                enterCityButtonPressedTag = true
                editor.putBoolean("gpsPermissionIsGivenTag", gpsPermissionIsGivenTag)
                editor.putBoolean("locationPermissionIsGivenTag", locationPermissionIsGivenTag)
                editor.putBoolean("enterCityButtonPressedTag", enterCityButtonPressedTag)
                editor.putBoolean("allowLocationButtonPressedTag", allowLocationButtonPressedTag)
                editor.putString("locationJSON", locationJSON)
                editor.putString("userCity", cityUserInput)
                editor.apply()

                // stop showing GPS location
                latitudeTM?.text = null
                longitudeTM?.text = null

                // pause updates
                handlerGPSSet.removeCallbacks(runnableGPSSet)
                handlerUserSet.removeCallbacks(runnableUserSet)
                // start updates
                handlerUserSet.postDelayed(Runnable { // starts regular updates
                    handlerUserSet.postDelayed(runnableUserSet, delay)
                    // Toast.makeText(this, "User-Set City Entered", Toast.LENGTH_SHORT).show()
                    GetWeatherTask().execute()
                }.also { runnableUserSet = it }, delay)
                GetWeatherTask().execute()

                // refresh layout here after input

                Toast.makeText(this, "User-Set City Entered", Toast.LENGTH_SHORT).show()
            }


            // set text for buttons
            if (gpsPermissionIsGivenTag && locationPermissionIsGivenTag) {
                if (allowLocationButtonPressedTag) {
                    btnAllowAccess.text = "ACCESS TO PHONE LOCATION IS ALLOWED"
                } else {
                    btnAllowAccess.text = "ACCESS TO PHONE LOCATION IS ALLOWED (PRESS TO USE)"
                }
            } else {
                btnAllowAccess.text = "ALLOW ACCESS TO PHONE LOCATION"
            }
        } else {
            Toast.makeText(applicationContext, "No Wifi/Mobile Data Connection", Toast.LENGTH_SHORT)
                .show()
        }

        // save values
        editor.putBoolean("gpsPermissionIsGivenTag", gpsPermissionIsGivenTag)
        editor.putBoolean("locationPermissionIsGivenTag", locationPermissionIsGivenTag)
        editor.putBoolean("enterCityButtonPressedTag", enterCityButtonPressedTag)
        editor.putBoolean("allowLocationButtonPressedTag", allowLocationButtonPressedTag)
        editor.putString("locationJSON", locationJSON)
        editor.putString("userCity", cityUserInput)
        editor.commit()
    }



    fun allowLocationButtonPressed(view: View?) { // leave view: View? here

        // load values
        val sharedSettings = getSharedPreferences("Shared_Settings", 0)
        val editor = sharedSettings.edit()
        gpsPermissionIsGivenTag = sharedSettings.getBoolean("gpsPermissionIsGivenTag", gpsPermissionIsGivenTag)
        locationPermissionIsGivenTag = sharedSettings.getBoolean("locationPermissionIsGivenTag", locationPermissionIsGivenTag)
        enterCityButtonPressedTag = sharedSettings.getBoolean("enterCityButtonPressedTag", enterCityButtonPressedTag)
        allowLocationButtonPressedTag = sharedSettings.getBoolean("allowLocationButtonPressedTag", allowLocationButtonPressedTag)

//        val btnSetCity = findViewById<Button>(R.id.buttonSetCity)
        val btnAllowAccess = findViewById<Button>(R.id.buttonAllowAccess)

        // check if Wifi and mobile data are active first
        // Returns connection type. 0: none; 1: mobile data; 2: wifi; 3: vpn
        if (getConnectionType() != 0) {

            // checks if GPS permission is granted and if not makes a dialog box to allow permission
            if (!locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
                val gpsAlertDialog = AlertDialog.Builder(this)

                // Setting Dialog Title
                gpsAlertDialog.setTitle("GPS Settings")

                // Setting Dialog Message
                gpsAlertDialog.setMessage("GPS is not enabled. \nPlease turn on LOCATION in settings")

                // On pressing Settings button
                gpsAlertDialog.setPositiveButton("Settings") { _, _ -> // Implicit intent
                    val intent = Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS)
                    startActivity(intent)
                }

                // on pressing Cancel button
                gpsAlertDialog.setNegativeButton(
                    "Cancel"
                ) { dialog, _ -> dialog.cancel() }

                // Showing Alert Message
                gpsAlertDialog.show()
            }


            // checks if location permission is granted and if not makes a dialog box to allow permission
            if (ContextCompat.checkSelfPermission(
                    this@MainActivity,
                    Manifest.permission.ACCESS_FINE_LOCATION
                ) == PackageManager.PERMISSION_GRANTED
            ) {
                // put stuff here
            } else {
                // if not granted opens dialog box
                ActivityCompat.requestPermissions(
                    this@MainActivity,
                    arrayOf(Manifest.permission.ACCESS_FINE_LOCATION),
                    1
                )
            }


            // checks if GPS permission has now been granted and sets tag
            gpsPermissionIsGivenTag = locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)

            // checks if location permission has now been granted and sets tag
            locationPermissionIsGivenTag = ContextCompat.checkSelfPermission(
                this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED

            // set Tags
            if (gpsPermissionIsGivenTag && locationPermissionIsGivenTag) { // location button has already been pressed to get here
                enterCityButtonPressedTag = false
                allowLocationButtonPressedTag = true

                //  save values
                editor.putBoolean("gpsPermissionIsGivenTag", gpsPermissionIsGivenTag)
                editor.putBoolean("locationPermissionIsGivenTag", locationPermissionIsGivenTag)
                editor.putBoolean("enterCityButtonPressedTag", enterCityButtonPressedTag)
                editor.putBoolean("allowLocationButtonPressedTag", allowLocationButtonPressedTag)
                editor.putString("locationJSON", locationJSON)
                editor.putString("userCity", cityUserInput)
                editor.apply()


                // pause updates
                handlerGPSSet.removeCallbacks(runnableGPSSet)
                handlerUserSet.removeCallbacks(runnableUserSet)
                // start updates
                handlerGPSSet.postDelayed(Runnable // starts regular updates
                {
                    handlerGPSSet.postDelayed(runnableGPSSet, delay)
//                        Toast.makeText(MainActivity.this, "GPS-Set City Updated", Toast.LENGTH_SHORT).show();
//                        this
                    GetWeatherTask().execute()
                }.also { runnableGPSSet = it }, delay)


                Toast.makeText(this, "Location Is Allowed", Toast.LENGTH_SHORT).show()
                latitudeTM?.text = "Getting Latitude (please wait)"
                longitudeTM?.text = "Getting Longitude (please wait)"
//                if (holder == null) {
//                // seems to work, crashes on first run without this
//                    this.location
//                }
                //getLocation(); // crashes app with this here on return from system settings
                GetWeatherTask().execute()
            } else {
                allowLocationButtonPressedTag = false
                // stop showing GPS location
                latitudeTM?.text = null
                longitudeTM?.text = null
            }


            // set text for buttons
            if (gpsPermissionIsGivenTag && locationPermissionIsGivenTag) {
                if (allowLocationButtonPressedTag) {
                    btnAllowAccess.text = "ACCESS TO PHONE LOCATION IS ALLOWED"
                } else {
                    btnAllowAccess.text = "ACCESS TO PHONE LOCATION IS ALLOWED (PRESS TO USE)"
                }
            } else {
                btnAllowAccess.text = "ALLOW ACCESS TO PHONE LOCATION"
            }
        } else {
            Toast.makeText(applicationContext, "No Wifi/Mobile Data Connection", Toast.LENGTH_SHORT).show()
        }

        // save values
        editor.putBoolean("gpsPermissionIsGivenTag", gpsPermissionIsGivenTag)
        editor.putBoolean("locationPermissionIsGivenTag", locationPermissionIsGivenTag)
        editor.putBoolean("enterCityButtonPressedTag", enterCityButtonPressedTag)
        editor.putBoolean("allowLocationButtonPressedTag", allowLocationButtonPressedTag)
        editor.putString("locationJSON", locationJSON)
        editor.putString("userCity", cityUserInput)
        editor.commit()
    }

    fun settingsButtonPressed(view: View?) { // keep view: View? here or it crashes
        setContentView(R.layout.activity_main)
        findViewById<View>(R.id.mainItemsContainer).visibility = View.GONE
        findViewById<View>(R.id.settingsItemsContainer).visibility = View.VISIBLE
        mainLayoutIsOpenTag = false
        settingsLayoutIsOpenTag = true


        // load checkbox ticked values
        clockTick?.isChecked = load("clockTick")
        locationTick?.isChecked = load("locationTick")
        weatherTick?.isChecked = load("weatherTick")
        updateTick?.isChecked = load("updateTick")
        dateTick?.isChecked = load("dateTick")
        logsTick?.isChecked = load("logsTick")
        moreAppsTick?.isChecked = load("moreAppsTick")
        homeButtonTick?.isChecked = load("homeButtonTick")
        homeButtonLongPressTick?.isChecked = load("homeButtonLongPressTick")
        saveValues()
        onResume()
    }

    fun exitSettings(view: View?) {
        setContentView(R.layout.activity_main)
        findViewById<View>(R.id.mainItemsContainer).visibility = View.VISIBLE
        findViewById<View>(R.id.settingsItemsContainer).visibility = View.GONE
        mainLayoutIsOpenTag = true
        settingsLayoutIsOpenTag = false


        // save checkbox values
        clockTick?.isChecked?.let { saveCheckboxValues(it, "clockTick") }
        locationTick?.isChecked?.let { saveCheckboxValues(it, "locationTick") }
        weatherTick?.isChecked?.let { saveCheckboxValues(it, "weatherTick") }
        updateTick?.isChecked?.let { saveCheckboxValues(it, "updateTick") }
        dateTick?.isChecked?.let { saveCheckboxValues(it, "dateTick") }
        logsTick?.isChecked?.let { saveCheckboxValues(it, "logsTick") }
        moreAppsTick?.isChecked?.let { saveCheckboxValues(it, "moreAppsTick") }
        homeButtonTick?.isChecked?.let { saveCheckboxValues(it, "homeButtonTick") }
        homeButtonLongPressTick?.isChecked?.let { saveCheckboxValues(it, "homeButtonLongPressTick") }
        saveValues()
        onResume()
    }

//    private fun exit() {
//        finish()
//        exitProcess(0)
//    }

    fun exit(view: View?) {

        // save checkbox values
        clockTick?.isChecked?.let { saveCheckboxValues(it, "clockTick") }
        locationTick?.isChecked?.let { saveCheckboxValues(it, "locationTick") }
        weatherTick?.isChecked?.let { saveCheckboxValues(it, "weatherTick") }
        updateTick?.isChecked?.let { saveCheckboxValues(it, "updateTick") }
        dateTick?.isChecked?.let { saveCheckboxValues(it, "dateTick") }
        logsTick?.isChecked?.let { saveCheckboxValues(it, "logsTick") }
        moreAppsTick?.isChecked?.let { saveCheckboxValues(it, "moreAppsTick") }
        homeButtonTick?.isChecked?.let { saveCheckboxValues(it, "homeButtonTick") }
        homeButtonLongPressTick?.isChecked?.let { saveCheckboxValues(it, "homeButtonLongPressTick") }

        saveValues()

        finish()
        exitProcess(0)


//        finish()
//        exitProcess(0)
    }

    private val location: Unit
        get() {

            // load values
            val sharedSettings = getSharedPreferences("Shared_Settings", 0)
//            val editor = Shared_Settings.edit()
            gpsPermissionIsGivenTag = sharedSettings.getBoolean("gpsPermissionIsGivenTag", gpsPermissionIsGivenTag)
            locationPermissionIsGivenTag = sharedSettings.getBoolean("locationPermissionIsGivenTag", locationPermissionIsGivenTag)

            // The minimum distance to change for updates in meters
            val minDistanceChangeForUpdates: Long = 2 // 2 meters

            // The minimum time between updates in milliseconds
            val minTimeBetweenUpdates = (1000 * 60).toLong() // 1 minute (1000/sec) // 8000
            locationManager = getSystemService(LOCATION_SERVICE) as LocationManager
            criteria = Criteria()
            holder = locationManager.getBestProvider(criteria!!, false)
            if (locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
                if (holder != null) {
                    if (ActivityCompat.checkSelfPermission(
                            this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(
                            this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED
                    ) {
                        return
                    }
                    Companion.location = locationManager.getLastKnownLocation(holder!!)
                    locationManager.requestLocationUpdates(
                        holder!!,
                        minTimeBetweenUpdates,
                        minDistanceChangeForUpdates.toFloat(),this)
                }
                if (gpsPermissionIsGivenTag && locationPermissionIsGivenTag && ((holder == null) or (locationJSON == null) or (latitude == 0.0))) {
                    latitudeTM!!.text = "Getting Latitude (please wait)"
                    longitudeTM!!.text = "Getting Longitude (please wait)"
                }
            }
        }

    override fun onLocationChanged(location: Location) {
        // load values
        val sharedSettings = getSharedPreferences("Shared_Settings", 0)
//        val editor = Shared_Settings.edit()
        gpsPermissionIsGivenTag = sharedSettings.getBoolean("gpsPermissionIsGivenTag", gpsPermissionIsGivenTag)
        locationPermissionIsGivenTag = sharedSettings.getBoolean("locationPermissionIsGivenTag", locationPermissionIsGivenTag)
        enterCityButtonPressedTag = sharedSettings.getBoolean("enterCityButtonPressedTag", enterCityButtonPressedTag)
        allowLocationButtonPressedTag = sharedSettings.getBoolean("allowLocationButtonPressedTag", allowLocationButtonPressedTag)

        if (allowLocationButtonPressedTag && gpsPermissionIsGivenTag && locationPermissionIsGivenTag) {
            latitudeTM?.text = buildString {
                append("Lat:  ")
                append(latitude)
            }
            longitudeTM?.text = buildString {
                append("Long:  ")
                append(longitude)
            }
        } else {
            latitudeTM?.text = null
            longitudeTM?.text = null
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onStatusChanged(provider: String, i: Int, bundle: Bundle) {
        TODO("Not yet implemented")
    }

    override fun onProviderEnabled(provider: String) {

        // load values
        val sharedSettings = getSharedPreferences("Shared_Settings", 0)
        val editor = sharedSettings.edit()
        enterCityButtonPressedTag = sharedSettings.getBoolean("enterCityButtonPressedTag", enterCityButtonPressedTag)
        allowLocationButtonPressedTag = sharedSettings.getBoolean(
            "allowLocationButtonPressedTag",
            allowLocationButtonPressedTag
        )
        locationJSON = sharedSettings.getString("locationJSON", locationJSON)
        Toast.makeText(this, "$provider is Enabled", Toast.LENGTH_SHORT).show()
        val btnSetCity = findViewById<Button>(R.id.buttonSetCity)
        val btnAllowAccess = findViewById<Button>(R.id.buttonAllowAccess)


        // checks if GPS permission has been granted and sets tag
        gpsPermissionIsGivenTag = locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER) == true


        // checks if location permission has been granted and sets tag
        locationPermissionIsGivenTag = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        if (enterCityButtonPressedTag) {
            allowLocationButtonPressedTag = false
            handlerGPSSet.removeCallbacks(runnableGPSSet)
            latitudeTM?.text = null
            longitudeTM?.text = null
            locationTM?.text = getString(R.string.using_user_entered_city_of, locationJSON)
        } else {
            handlerUserSet.removeCallbacks(runnableUserSet)
            handlerGPSSet.removeCallbacks(runnableGPSSet)
            latitudeTM?.text = null
            longitudeTM?.text = null
            locationTM?.text = null
        }


        // set text for buttons
        if (gpsPermissionIsGivenTag && locationPermissionIsGivenTag) {
            if (allowLocationButtonPressedTag) {
                btnAllowAccess.text = getString(R.string.access_to_phone_location_is_allowed)
            } else {
                btnAllowAccess.text =
                    getString(R.string.access_to_phone_location_is_allowed_press_to_use)
            }
        } else {
            btnAllowAccess.text = getString(R.string.allow_access_to_phone_location)
        }


        // save values
        editor.putBoolean("gpsPermissionIsGivenTag", gpsPermissionIsGivenTag)
        editor.putBoolean("locationPermissionIsGivenTag", locationPermissionIsGivenTag)
        editor.putBoolean("enterCityButtonPressedTag", enterCityButtonPressedTag)
        editor.putBoolean("allowLocationButtonPressedTag", allowLocationButtonPressedTag)
        editor.putString("locationJSON", locationJSON)
        editor.apply()
    }

    override fun onProviderDisabled(provider: String) {

        // load values
        val sharedSettings = getSharedPreferences("Shared_Settings", 0)
        val editor = sharedSettings.edit()
        enterCityButtonPressedTag = sharedSettings.getBoolean("enterCityButtonPressedTag", enterCityButtonPressedTag)
        allowLocationButtonPressedTag = sharedSettings.getBoolean("allowLocationButtonPressedTag", allowLocationButtonPressedTag)
        locationJSON = sharedSettings.getString("locationJSON", locationJSON)
        Toast.makeText(this, "$provider is Disabled", Toast.LENGTH_SHORT).show()
        val btnSetCity = findViewById<Button>(R.id.buttonSetCity)
        val btnAllowAccess = findViewById<Button>(R.id.buttonAllowAccess)


        // checks if GPS permission is still granted and sets tag
        gpsPermissionIsGivenTag = locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)


        // checks if location permission is still granted and sets tag
        locationPermissionIsGivenTag = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        if (!gpsPermissionIsGivenTag or !locationPermissionIsGivenTag) {
            allowLocationButtonPressedTag = false
            handlerGPSSet.removeCallbacks(runnableGPSSet)
            latitudeTM?.text = null
            longitudeTM?.text = null
        }
        if (enterCityButtonPressedTag) {
            latitudeTM?.text = null
            longitudeTM?.text = null
            locationTM?.text = "Using user-entered City of:  $locationJSON"
        } else {
            handlerUserSet.removeCallbacks(runnableUserSet)
            latitudeTM?.text = null
            longitudeTM?.text = null
            locationTM?.text = null
        }


        // set text for buttons
        if (gpsPermissionIsGivenTag && locationPermissionIsGivenTag) {
            if (allowLocationButtonPressedTag) {
                btnAllowAccess.text = "ACCESS TO PHONE LOCATION IS ALLOWED"
            } else {
                btnAllowAccess.text = "ACCESS TO PHONE LOCATION IS ALLOWED (PRESS TO USE)"
            }
        } else {
            btnAllowAccess.text = "ALLOW ACCESS TO PHONE LOCATION"
        }


        // save values
        editor.putBoolean("gpsPermissionIsGivenTag", gpsPermissionIsGivenTag)
        editor.putBoolean("locationPermissionIsGivenTag", locationPermissionIsGivenTag)
        editor.putBoolean("enterCityButtonPressedTag", enterCityButtonPressedTag)
        editor.putBoolean("allowLocationButtonPressedTag", allowLocationButtonPressedTag)
        editor.putString("locationJSON", locationJSON)
        editor.apply()
    }

    override fun onPointerCaptureChanged(hasCapture: Boolean) {}
    private fun updateWidget() { // send intent broadcast to widget from this activity:
        val intent = Intent(this, Widget1Activity::class.java)
        intent.setAction(AppWidgetManager.ACTION_APPWIDGET_UPDATE)
        // Use an array and EXTRA_APPWIDGET_IDS instead of AppWidgetManager.EXTRA_APPWIDGET_ID,
        // since it seems the onUpdate() is only fired on that:
        val ids = AppWidgetManager.getInstance(application)
            .getAppWidgetIds(ComponentName(application, Widget1Activity::class.java))
        intent.putExtra(AppWidgetManager.EXTRA_APPWIDGET_IDS, ids)
        sendBroadcast(intent)
    }

    internal inner class GetWeatherTask() : AsyncTask<String?, Void?, String?>() {

        override fun onPreExecute() {
            super.onPreExecute()

            // load values
            val sharedSettings = getSharedPreferences("Shared_Settings", 0)
//            val editor = Shared_Settings.edit()
            firstRunTag = sharedSettings.getBoolean("firstRunTag", firstRunTag)
            enterCityButtonPressedTag = sharedSettings.getBoolean("enterCityButtonPressedTag", enterCityButtonPressedTag)
            allowLocationButtonPressedTag = sharedSettings.getBoolean("allowLocationButtonPressedTag", allowLocationButtonPressedTag)
            cityUserInput = sharedSettings.getString("userCity", cityUserInput)
            nightTag = sharedSettings.getBoolean("nightTag", nightTag)
            mainLayoutIsOpenTag = sharedSettings.getBoolean("mainLayoutIsOpenTag", mainLayoutIsOpenTag)
            settingsLayoutIsOpenTag = sharedSettings.getBoolean("settingsLayoutIsOpenTag", settingsLayoutIsOpenTag)
            locationJSON = sharedSettings.getString("locationJSON", locationJSON)
            apiKey = sharedSettings.getString("API_keyText", apiKey)
        }

        @Deprecated("Deprecated in Java")
        override fun doInBackground(args: Array<String?>): String? {
            if (allowLocationButtonPressedTag) {
                latitude = Companion.location!!.latitude
                longitude = Companion.location!!.longitude
            }
            val response: String? = if (allowLocationButtonPressedTag) {
                executeGet("https://api.openweathermap.org/data/2.5/weather?lat=$latitude&lon=$longitude&units=metric&appid=$apiKey")
            } else {
                executeGet("https://api.openweathermap.org/data/2.5/weather?q=$cityUserInput&units=metric&appid=$apiKey")
            }
            return response
        }

        @Deprecated("Deprecated in Java")
        override fun onPostExecute(result: String?) {
            try {
                val jsonObj = result?.let { JSONObject(it) }
                val main = jsonObj?.getJSONObject("main")
                val sys = jsonObj?.getJSONObject("sys")
                val weather = jsonObj?.getJSONArray("weather")?.getJSONObject(0)


                // collect strings and data from json object
                val locationJSON = jsonObj?.getString("name") // + ", " + sys.getString("country");
                val temperature = (main?.let { String.format("%.0f", it.getDouble("temp")) } + "°C")
                val description = weather?.getString("description") // String icon = weather.getString("main");
                val sunrise = sys?.getLong("sunrise")
                val sunset = sys?.getLong("sunset")
                val updatedAt = jsonObj?.getLong("dt")
                val updatedAtFormatted = "Updated:   " + SimpleDateFormat("HH:mm   dd/MM/yy", Locale.ENGLISH).format(updatedAt!! * 1000)


                // save values
                val sharedSettings = getSharedPreferences("Shared_Settings", 0)
                val editor = sharedSettings.edit()
                editor.putString("temperature", temperature)
                editor.putString("description", description)
                editor.putBoolean("nightTag", nightTag)
                if (sunrise != null) {
                    editor.putLong("sunrise", sunrise)
                }
                if (sunset != null) {
                    editor.putLong("sunset", sunset)
                }
                editor.putLong("updatedAt", updatedAt)
                editor.putString("updatedAtFormatted", updatedAtFormatted)
                editor.putString("locationJSON", locationJSON)
                editor.putString("userCity", cityUserInput)
                editor.putBoolean("allowLocationButtonPressedTag", allowLocationButtonPressedTag)
                editor.apply()
            } catch (e: JSONException) { // if not found, possibly if empty or if userCity?
//                if ((!allowLocationButtonPressedTag) && (userCity == "")) {
//                    Toast.makeText(MainActivity.this, "Please Set Location in App", Toast.LENGTH_SHORT).show();
//                } else {
//                    Toast.makeText(MainActivity.this, "Oops, Unable to get data from openweathermap!", Toast.LENGTH_SHORT).show();
//                }
            }
            postWeatherTask()
        }

        private fun postWeatherTask() {

            // load and save values
            val sharedSettings = getSharedPreferences("Shared_Settings", 0)
            val editor = sharedSettings.edit()
            temperature = sharedSettings.getString("temperature", temperature)
            description = sharedSettings.getString("description", description)
            nightTag = sharedSettings.getBoolean("nightTag", nightTag)
            sunrise = sharedSettings.getLong("sunrise", sunrise)
            sunset = sharedSettings.getLong("sunset", sunset)
            updatedAt = sharedSettings.getLong("updatedAt", updatedAt)
            updatedAtFormatted = sharedSettings.getString("updatedAtFormatted", updatedAtFormatted)
            locationJSON = sharedSettings.getString("locationJSON", locationJSON)
            cityUserInput = sharedSettings.getString("userCity", cityUserInput)
            allowLocationButtonPressedTag = sharedSettings.getBoolean("allowLocationButtonPressedTag", allowLocationButtonPressedTag)


            // main layout text id's
            updatedAtTM = findViewById(R.id.updatedAtMain)
            latitudeTM = findViewById(R.id.showLatitudeMain)
            longitudeTM = findViewById(R.id.showLongitudeMain)
            locationTM = findViewById(R.id.showLocationMain)


            // settings layout text id's
            updatedAtTS = findViewById(R.id.updatedAtSettings)
            locationTS = findViewById(R.id.showLocationSettings)
            temperatureTS = findViewById(R.id.temperatureSettings)
            descriptionTS = findViewById(R.id.descriptionSettings)


            // night tag
            nightTag = updatedAt < sunrise || updatedAt >= sunset
            if ("Greater London".equals(locationJSON, ignoreCase = true)) {
                locationJSON = "London"
            }


            // below values are defined in both main/settings layouts but are hidden where not needed
            // set text for main layout
            updatedAtTM?.text = updatedAtFormatted
            if (allowLocationButtonPressedTag) {
                if ((holder == null) or (locationJSON == null) or (latitude == 0.0)) {
                    latitudeTM?.text = getString(R.string.getting_latitude_please_wait)
                    longitudeTM?.text = getString(R.string.getting_longitude_please_wait)
                } else {
                    latitudeTM?.text = buildString {
                        append("Lat:  ")
                        append(latitude)
                    }
                    longitudeTM?.text = buildString {
                        append("Long:  ")
                        append(longitude)
                    }
                }
                locationTM?.text = getString(R.string.using_gps_located_city_of, locationJSON)
            } else {
                if ((holder == null) or (locationJSON == null) or (latitude == 0.0)) {
                    locationTM?.text = null
                } else {
                    locationTM?.text = getString(R.string.using_user_entered_city_of, locationJSON)
                }
                city?.setText(locationJSON)
                cityUserInput = city?.text.toString()
            }

            // set text for settings layout
            updatedAtTS?.text = updatedAtFormatted
            locationTS?.text = locationJSON
            temperatureTS?.text = temperature
            descriptionTS?.text = description

            updateWidget()

            // save values
            editor.putString("temperature", temperature)
            editor.putString("description", description)
            editor.putBoolean("nightTag", nightTag)
            editor.putLong("sunrise", sunrise)
            editor.putLong("sunset", sunset)
            editor.putLong("updatedAt", updatedAt)
            editor.putString("updatedAtFormatted", updatedAtFormatted)
            editor.putString("locationJSON", locationJSON)
            editor.putString("userCity", cityUserInput)
            editor.putBoolean("allowLocationButtonPressedTag", allowLocationButtonPressedTag)
            editor.apply()
        }
    }

    companion object {
        private var location: Location? = null
        var latitude = 0.0
        var longitude = 0.0
    }

    private fun getConnectionType(): Int {
        var result = 0 // Returns connection type. 0: none; 1: mobile data; 2: wifi; 3: vpn
        val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager?
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            cm?.run {
                cm.getNetworkCapabilities(cm.activeNetwork)?.run {
                    if (hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)) {
                        result = 1
                    } else if (hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) {
                        result = 2
                    } else if (hasTransport(NetworkCapabilities.TRANSPORT_VPN)){
                        result = 3
                    }
                }
            }
        } else {
            cm?.run {
                cm.activeNetworkInfo?.run {
                    result = when (type) {
                        ConnectivityManager.TYPE_MOBILE -> 1
                        ConnectivityManager.TYPE_WIFI -> 2
                        ConnectivityManager.TYPE_VPN -> 3
                        else -> 0 // Handle other network types if needed
                    }
                }
            }
        }
        return result
    }

}

